import { useMemo, useState } from "react"

type FieldType = "text" | "list" | "number" | "checkbox" | "date" | "datetime" | "select" | "relation"

type Field = {
  id: number
  name: string
  type: FieldType
  multiple?: boolean
  target?: string
  icon?: string
  options?: { name: string color: string }[]
  warning?: string
}

const initialFields: Field[] = [
  { id: 1, name: "Title", type: "text" },
  {
    id: 2,
    name: "Status",
    type: "select",
    options: [
      { name: "Backlog", color: "gray" },
      { name: "In progress", color: "blue" },
      { name: "Blocked", color: "red" },
      { name: "Done", color: "green" },
    ],
  },
  {
    id: 3,
    name: "Projects",
    type: "relation",
    multiple: true,
    target: "Projects",
    icon: "🚀",
    warning: "“Projects” defines this field as a single relation.",
  },
  {
    id: 4,
    name: "Priority",
    type: "select",
    options: [
      { name: "Low", color: "green" },
      { name: "Medium", color: "orange" },
      { name: "High", color: "red" },
    ],
  },
  { id: 5, name: "Due date", type: "date" },
  { id: 6, name: "Estimate", type: "number" },
  { id: 7, name: "Tags", type: "list" },
  { id: 8, name: "Completed", type: "checkbox" },
  { id: 9, name: "Owner", type: "relation", target: "People", icon: "👤" },
  { id: 10, name: "Created", type: "datetime" },
  { id: 11, name: "Notes", type: "text" },
  {
    id: 12,
    name: "Milestone",
    type: "relation",
    target: "Milestones",
    icon: "🏁",
  },
  {
    id: 13,
    name: "Area",
    type: "select",
    options: [
      { name: "Product", color: "purple" },
      { name: "Research", color: "cyan" },
    ],
  },
  { id: 14, name: "Links", type: "list" },
  { id: 15, name: "Progress", type: "number" },
  { id: 16, name: "Reviewed", type: "checkbox" },
  { id: 17, name: "Start date", type: "date" },
  { id: 18, name: "Last edited", type: "datetime" },
  {
    id: 19,
    name: "Clients",
    type: "relation",
    multiple: true,
    target: "Clients",
    icon: "🏢",
  },
  {
    id: 20,
    name: "Channel",
    type: "select",
    options: [
      { name: "Web", color: "blue" },
      { name: "Email", color: "pink" },
    ],
  },
  { id: 21, name: "Source", type: "text" },
  { id: 22, name: "Archived", type: "checkbox" },
]

const typeLabels: Record<FieldType, string> = {
  text: "Text",
  list: "List",
  number: "Number",
  checkbox: "Checkbox",
  date: "Date",
  datetime: "Date & time",
  select: "Select",
  relation: "Relation",
}

const typeIcons: Record<FieldType, string> = {
  text: "text",
  list: "list",
  number: "hash",
  checkbox: "check-square",
  date: "calendar",
  datetime: "clock",
  select: "circle-dot",
  relation: "link",
}

function Icon({ name, size = 16 }: { name: string size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    x: (
      <>
        <path d="M18 6 6 18M6 6l12 12" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    undo: (
      <>
        <path d="M9 14 4 9l5-5" />
        <path d="M4 9h10a6 6 0 0 1 6 6v1" />
      </>
    ),
    trash: (
      <>
        <path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5" />
      </>
    ),
    chevron: (
      <>
        <path d="m9 18 6-6-6-6" />
      </>
    ),
    down: (
      <>
        <path d="m6 9 6 6 6-6" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41" />
      </>
    ),
    moon: (
      <>
        <path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z" />
      </>
    ),
    text: (
      <>
        <path d="M4 6V4h16v2M12 4v16M8 20h8" />
      </>
    ),
    list: (
      <>
        <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
      </>
    ),
    hash: (
      <>
        <path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18" />
      </>
    ),
    "check-square": (
      <>
        <rect x="3" y="3" width="18" height="18" rx="3" />
        <path d="m8 12 3 3 5-6" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    "circle-dot": (
      <>
        <circle cx="12" cy="12" r="9" />
        <circle cx="12" cy="12" r="3" />
      </>
    ),
    link: (
      <>
        <path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1.1 1.1M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1.1-1.1" />
      </>
    ),
    alert: (
      <>
        <path d="M12 3 2.6 20h18.8L12 3Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    layers: (
      <>
        <path d="m12 2 9 5-9 5-9-5 9-5Z" />
        <path d="m3 12 9 5 9-5M3 17l9 5 9-5" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    info: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 11v5M12 8h.01" />
      </>
    ),
    command: (
      <>
        <path d="M9 6V5a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v14a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6Z" />
      </>
    ),
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

function TypeSelect({
  field,
  onChange,
}: {
  field: Field
  onChange: (type: FieldType) => void
}) {
  return (
    <label className="type-select">
      <span className="type-icon">
        <Icon name={typeIcons[field.type]} size={15} />
      </span>
      <select
        value={field.type}
        onChange={(e) => onChange(e.target.value as FieldType)}
        aria-label={`Type for ${field.name}`}
      >
        {Object.entries(typeLabels).map(([value, label]) => (
          <option value={value} key={value}>
            {label}
          </option>
        ))}
      </select>
      <Icon name="down" size={13} />
    </label>
  )
}

function FieldDetail({
  field,
  onUpdate,
}: {
  field: Field
  onUpdate: (patch: Partial<Field>) => void
}) {
  if (field.type === "select") {
    return (
      <div className="field-detail">
        <div className="option-list">
          {(field.options ?? []).map((option) => (
            <span className="option-chip" key={option.name}>
              <i className={`color-dot ${option.color}`} />
              {option.name}
            </span>
          ))}
          <button className="add-option">
            <Icon name="plus" size={12} /> Option
          </button>
        </div>
        <label className="toggle-label">
          <span>Allow multiple</span>
          <button
            className={`switch ${field.multiple ? "on" : ""}`}
            onClick={() => onUpdate({ multiple: !field.multiple })}
            aria-label="Allow multiple"
          >
            <i />
          </button>
        </label>
      </div>
    )
  }
  if (field.type === "relation") {
    return (
      <div className="field-detail relation-detail">
        <label>
          <span>Related base</span>
          <button className="base-picker">
            <span>{field.icon ?? "◫"}</span>
            {field.target ?? "Choose a base"}
            <Icon name="down" size={13} />
          </button>
        </label>
        <label className="toggle-label">
          <span>Allow multiple</span>
          <button
            className={`switch ${field.multiple ? "on" : ""}`}
            onClick={() => onUpdate({ multiple: !field.multiple })}
            aria-label="Allow multiple"
          >
            <i />
          </button>
        </label>
      </div>
    )
  }
  return null
}

export default function App() {
  const [dark, setDark] = useState(true)
  const [defaultIcon, setDefaultIcon] = useState("☑️")
  const [direction, setDirection] = useState<"table" | "inspector" | "groups">(
    "table",
  )
  const [fields, setFields] = useState(initialFields)
  const [expanded, setExpanded] = useState<number | null>(2)
  const [selected, setSelected] = useState(2)
  const [draftNames, setDraftNames] = useState<Record<number, string>>({})
  const [removed, setRemoved] = useState<{ field: Field index: number } | null>(
    null,
  )
  const [search, setSearch] = useState("")

  const pendingRenames = Object.entries(draftNames)
    .map(([id, name]) => ({
      field: fields.find((f) => f.id === Number(id)),
      name,
    }))
    .filter(
      (item) =>
        item.field && item.name.trim() && item.field.name !== item.name.trim(),
    ) as { field: Field name: string }[]

  const visibleFields = fields.filter((field) =>
    field.name.toLowerCase().includes(search.toLowerCase()),
  )
  const selectedField =
    fields.find((field) => field.id === selected) ?? fields[0]
  const groups = useMemo(() => {
    return Object.entries(
      visibleFields.reduce<Record<string, Field[]>>((acc, field) => {
        const group =
          field.type === "relation"
            ? "Relations"
            : field.type === "select"
              ? "Choices"
              : "Properties"
        ;(acc[group] ??= []).push(field)
        return acc
      }, {}),
    )
  }, [visibleFields])

  const updateField = (id: number, patch: Partial<Field>) => {
    setFields((current) =>
      current.map((field) =>
        field.id === id ? { ...field, ...patch } : field,
      ),
    )
  }

  const removeField = (field: Field) => {
    const index = fields.findIndex((item) => item.id === field.id)
    setRemoved({ field, index })
    setFields((current) => current.filter((item) => item.id !== field.id))
    setDraftNames((current) => {
      const next = { ...current }
      delete next[field.id]
      return next
    })
  }

  const undoRemove = () => {
    if (!removed) return
    setFields((current) => {
      const next = [...current]
      next.splice(removed.index, 0, removed.field)
      return next
    })
    setRemoved(null)
  }

  const addField = () => {
    const nextId = Math.max(0, ...fields.map((field) => field.id)) + 1
    const field = {
      id: nextId,
      name: "Untitled field",
      type: "text" as FieldType,
    }
    setFields((current) => [...current, field])
    setSelected(nextId)
    setDraftNames((current) => ({ ...current, [nextId]: "Untitled field" }))
  }

  const applyRenames = () => {
    pendingRenames.forEach(({ field, name }) =>
      updateField(field.id, { name: name.trim() }),
    )
    setDraftNames({})
  }

  const renderWarning = (field: Field) =>
    field.warning && (
      <div className="warning-row">
        <Icon name="alert" size={15} />
        <span>{field.warning}</span>
        <button>Review base</button>
      </div>
    )

  const renderTableRow = (field: Field) => {
    const detailOpen =
      expanded === field.id &&
      (field.type === "select" || field.type === "relation")
    return (
      <div
        className={`field-row-wrap ${field.warning ? "has-warning" : ""}`}
        key={field.id}
      >
        <div className="field-row">
          <button
            className={`disclosure ${detailOpen ? "open" : ""}`}
            onClick={() => setExpanded(detailOpen ? null : field.id)}
            disabled={field.type !== "select" && field.type !== "relation"}
            aria-label="Show details"
          >
            {(field.type === "select" || field.type === "relation") && (
              <Icon name="chevron" size={14} />
            )}
          </button>
          <input
            className="name-input"
            value={draftNames[field.id] ?? field.name}
            onChange={(e) =>
              setDraftNames((current) => ({
                ...current,
                [field.id]: e.target.value,
              }))
            }
            aria-label={`Rename ${field.name}`}
          />
          <TypeSelect
            field={field}
            onChange={(type) => {
              updateField(field.id, { type })
              if (type === "select" || type === "relation")
                setExpanded(field.id)
            }}
          />
          <div className="summary">
            {field.type === "select" && (
              <>
                {field.options
                  ?.slice(0, 3)
                  .map((o) => (
                    <i key={o.name} className={`color-dot ${o.color}`} />
                  ))}
                <span>{field.options?.length ?? 0} options</span>
              </>
            )}
            {field.type === "relation" && (
              <>
                <span>{field.icon}</span>
                <span>{field.target}</span>
                {field.multiple && <em>Multiple</em>}
              </>
            )}
            {field.type !== "select" && field.type !== "relation" && (
              <span className="muted">—</span>
            )}
          </div>
          <button
            className="icon-button danger-hover"
            onClick={() => removeField(field)}
            aria-label={`Remove ${field.name}`}
          >
            <Icon name="trash" size={15} />
          </button>
        </div>
        {renderWarning(field)}
        {detailOpen && (
          <FieldDetail
            field={field}
            onUpdate={(patch) => updateField(field.id, patch)}
          />
        )}
      </div>
    )
  }

  return (
    <main className={dark ? "app dark" : "app"}>
      <div className="workspace">
        <aside className="fake-sidebar">
          <div className="vault-name">
            <Icon name="layers" size={15} /> Atlas vault
          </div>
          {["Inbox", "Projects", "Tasks", "People", "Archive"].map(
            (item, index) => (
              <div
                className={`nav-item ${index === 2 ? "active" : ""}`}
                key={item}
              >
                <Icon
                  name={index === 2 ? "check-square" : "chevron"}
                  size={14}
                />
                {item}
              </div>
            ),
          )}
        </aside>
        <section className="fake-note">
          <div className="note-line wide" />
          <div className="note-line" />
          <div className="note-line short" />
        </section>
      </div>

      <div className="prototype-bar">
        <div>
          <span className="eyebrow">Layout directions</span>
          <nav className="direction-tabs" aria-label="Layout directions">
            <button
              className={direction === "table" ? "active" : ""}
              onClick={() => setDirection("table")}
            >
              <b>01</b> Dense table <span>Refined</span>
            </button>
            <button
              className={direction === "inspector" ? "active" : ""}
              onClick={() => setDirection("inspector")}
            >
              <b>02</b> Split inspector
            </button>
            <button
              className={direction === "groups" ? "active" : ""}
              onClick={() => setDirection("groups")}
            >
              <b>03</b> Type groups
            </button>
          </nav>
        </div>
        <button
          className="theme-button"
          onClick={() => setDark(!dark)}
          aria-label="Toggle theme"
        >
          <Icon name={dark ? "sun" : "moon"} size={16} />{" "}
          {dark ? "Light" : "Dark"}
        </button>
      </div>

      <div className="backdrop" />
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
      >
        <header className="modal-header">
          <div className="base-icon">✓</div>
          <div>
            <h1 id="dialog-title">Schema settings</h1>
            <p>
              Tasks <span>·</span> {fields.length} fields
            </p>
          </div>
          <div className="entry-icon-setting">
            <span>Default entry icon</span>
            <input
              className="entry-icon-input"
              value={defaultIcon}
              onChange={(event) => setDefaultIcon(event.target.value)}
              placeholder="e.g. ☑️"
              aria-label="Default entry icon"
            />
          </div>
          <button className="icon-button close-button" aria-label="Close">
            <Icon name="x" size={18} />
          </button>
        </header>

        <div className="toolbar">
          <label className="search">
            <Icon name="search" size={14} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Find a field…"
            />
            <kbd>⌘ F</kbd>
          </label>
          <button className="add-field" onClick={addField}>
            <Icon name="plus" size={15} /> Add field
          </button>
        </div>

        {direction === "table" && (
          <div className="table-shell">
            <div className="column-head">
              <span>Field name</span>
              <span>Type</span>
              <span>Details</span>
              <span />
            </div>
            <div className="field-list">
              {visibleFields.map(renderTableRow)}
            </div>
          </div>
        )}

        {direction === "inspector" && (
          <div className="inspector-layout">
            <div className="inspector-list">
              {visibleFields.map((field) => (
                <button
                  key={field.id}
                  className={selected === field.id ? "selected" : ""}
                  onClick={() => setSelected(field.id)}
                >
                  <span className="type-icon">
                    <Icon name={typeIcons[field.type]} size={15} />
                  </span>
                  <span>
                    <b>{draftNames[field.id] ?? field.name}</b>
                    <small>{typeLabels[field.type]}</small>
                  </span>
                  {field.warning && <Icon name="alert" size={14} />}
                  <Icon name="chevron" size={14} />
                </button>
              ))}
            </div>
            {selectedField && (
              <div className="inspector-panel">
                <span className="section-label">Selected field</span>
                <label className="stacked-label">
                  Field name
                  <input
                    value={draftNames[selectedField.id] ?? selectedField.name}
                    onChange={(e) =>
                      setDraftNames((c) => ({
                        ...c,
                        [selectedField.id]: e.target.value,
                      }))
                    }
                  />
                </label>
                <label className="stacked-label">
                  Property type
                  <TypeSelect
                    field={selectedField}
                    onChange={(type) => updateField(selectedField.id, { type })}
                  />
                </label>
                {renderWarning(selectedField)}
                <FieldDetail
                  field={selectedField}
                  onUpdate={(patch) => updateField(selectedField.id, patch)}
                />
                <button
                  className="remove-text"
                  onClick={() => removeField(selectedField)}
                >
                  <Icon name="trash" size={15} /> Remove field
                </button>
              </div>
            )}
          </div>
        )}

        {direction === "groups" && (
          <div className="groups-layout">
            {groups.map(([name, groupFields]) => (
              <section className="field-group" key={name}>
                <header>
                  <span>{name}</span>
                  <em>{groupFields.length}</em>
                </header>
                {groupFields.map((field) => (
                  <div className="group-row" key={field.id}>
                    <span className="type-icon">
                      <Icon name={typeIcons[field.type]} size={15} />
                    </span>
                    <input
                      value={draftNames[field.id] ?? field.name}
                      onChange={(e) =>
                        setDraftNames((c) => ({
                          ...c,
                          [field.id]: e.target.value,
                        }))
                      }
                    />
                    <TypeSelect
                      field={field}
                      onChange={(type) => updateField(field.id, { type })}
                    />
                    <button
                      className="icon-button danger-hover"
                      onClick={() => removeField(field)}
                    >
                      <Icon name="trash" size={15} />
                    </button>
                  </div>
                ))}
              </section>
            ))}
          </div>
        )}

        <footer className="modal-footer">
          <div className="rename-status">
            {pendingRenames.length > 0 ? (
              <>
                <span className="rename-badge">
                  <Icon name="command" size={14} /> {pendingRenames.length}
                </span>
                <div>
                  <b>
                    {pendingRenames.length} pending{" "}
                    {pendingRenames.length === 1 ? "rename" : "renames"}
                  </b>
                  <p>
                    {pendingRenames
                      .slice(0, 2)
                      .map(({ field, name }) => `${field.name} → ${name}`)
                      .join(" · ")}
                    {pendingRenames.length > 2 &&
                      ` · +${pendingRenames.length - 2} more`}
                  </p>
                </div>
                <button className="discard" onClick={() => setDraftNames({})}>
                  Discard
                </button>
                <button className="apply" onClick={applyRenames}>
                  Review & apply…
                </button>
              </>
            ) : (
              <>
                <Icon name="info" size={15} />
                <span>
                  Type and detail changes apply immediately. Field renames
                  require confirmation.
                </span>
              </>
            )}
          </div>
        </footer>
      </section>

      {removed && (
        <div className="toast">
          <span>“{removed.field.name}” removed</span>
          <button onClick={undoRemove}>
            <Icon name="undo" size={14} /> Undo
          </button>
          <button className="icon-button" onClick={() => setRemoved(null)}>
            <Icon name="x" size={14} />
          </button>
        </div>
      )}
    </main>
  )
}
